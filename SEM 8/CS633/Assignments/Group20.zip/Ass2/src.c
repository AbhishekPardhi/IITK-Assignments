#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mpi.h"

// #pragma prutor-mpi-args: -np 12 -ppn 6
// #pragma prutor-mpi-sysargs: 4 16777216 10 0
// #pragma prutor-mpi-sysargs: 4 67108864 10 0

// mpirun –np P –f hostfile ./halo Px N <num_time_steps> <seed> <stencil>
// Assumptions:
//  Px is number of processes in x direction
//  N is perfect square

int main(int argc, char *argv[]) {

    int rank, size, position=0;
    MPI_Status status;
    double sTime, eTime, time;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    int N = atoi(argv[2]);
    int rN = sqrt(N);
    int Px = atoi(argv[1]); // Number of processes in x direction
    int Py = size/Px; // Number of processes in y direction
    int num_steps = atoi(argv[3]); // Number of time steps
    int seed = atoi(argv[4]); // Seed for random number generation
    // int stencil = atoi(argv[5]); // Stencil type
    int stencil = 9; // Stencil type
    int count = (stencil==5?1:2); // Count of elements to be sent/received

    int lenx = rN/Px; // Number of data points in x direction for each process
    int leny = rN/Py; // Number of data points in y direction for each process
    
    // set lenx and leny for the last process in each row and column
    if(rank/Px == Py-1){
        leny = rN - leny*(Py-1);
    }
    if(rank%Px == Px-1){
        lenx = rN - lenx*(Px-1);
    }

    // Main data array surrounded by halo region
    // Using temp array to store updated values
    double data[leny+4][lenx+4], temp[leny+4][lenx+4];
    double rowSendBuf[count*lenx];
    double rowRecvBuf[count*lenx];
    double colSendBuf[count*leny];
    double colRecvBuf[count*leny];
    double intraNodeSendBuf[2*count*lenx];
    double intraNodeRecvBuf[2*count*lenx*Px];
    double interNodeSendBuf[count*lenx*Px];
    double interNodeRecvBuf[2*count*lenx*Px];
    double intraNodeRecvSmallBuf[2*count*lenx];
    int rowBufSz = count*lenx*16;
    int colBufSz = count*leny*16;
    int interNodeBufSz = count*lenx*Px*16;

    int row = rank/Px; // Row number of process
    int col = rank%Px; // Column number of process

    // Initialize data with random values
    for(int i = 0; i < leny+4; i++){
        for(int j = 0; j < lenx+4; j++){
            if(i<=1 || j<=1 || i>=leny+2 || j>=lenx+2){
                data[i][j] = -1;
                temp[i][j] = -1;
            }
            else{
                data[i][j] =  abs(rand()+((i-2)*rand()+(j-2)*rank))/100;
                temp[i][j] = data[i][j];
            }
        }
    }

    int newRank, newSize;
    MPI_Comm intraNodeComm;
    MPI_Comm_split(MPI_COMM_WORLD, rank/Px, rank, &intraNodeComm);
    MPI_Comm_rank(intraNodeComm, &newRank);
    MPI_Comm_size(intraNodeComm, &newSize);

    MPI_Group g_group;
    MPI_Comm_group(MPI_COMM_WORLD, &g_group);
    int ranks[Py];
    for(int i=0; i<Py; i++){
        ranks[i] = i*Px;
    }
    MPI_Group interNodeGroup;
    MPI_Group_incl(g_group, Py, ranks, &interNodeGroup);
    MPI_Comm interNodeComm;
    MPI_Comm_create_group(MPI_COMM_WORLD, interNodeGroup, 0, &interNodeComm);


    for(int leader=0; leader<2; leader++){
        MPI_Comm rowComm = (leader==0?MPI_COMM_WORLD:intraNodeComm);
        sTime = MPI_Wtime();
        if(leader==1) rank=newRank;
        
        // Main loop of communication and computation
        for(int time_step=0; time_step<num_steps; time_step++){
            // Communicate Values
            if(col%2==0 && col<Px-1){
                // Send/recv right neighbour from even ranks
                // Pack column and send right
                position = 0;
                for(int i=0; i<leny; i++){
                    MPI_Pack(&data[i+2][lenx-count+2], count, MPI_DOUBLE, colSendBuf, colBufSz, &position, rowComm);
                }
                MPI_Send(colSendBuf, position, MPI_PACKED, rank+1, rank+1, rowComm);
                // Unpack received column
                MPI_Recv(colRecvBuf, colBufSz, MPI_PACKED, rank+1, rank, rowComm, &status);
                for(int i=0; i<leny; i++){
                    MPI_Unpack(colRecvBuf, colBufSz, &position, &temp[i+2][lenx+2], count, MPI_DOUBLE, rowComm);
                }
            }
            else if(col%2!=0 && col>0){
                // Send/recv left neighbour from odd ranks
                // Unpack received column
                position = 0;
                MPI_Recv(colRecvBuf, colBufSz, MPI_PACKED, rank-1, rank, rowComm, &status);
                for(int i=0; i<leny; i++){
                    MPI_Unpack(colRecvBuf, colBufSz, &position, &temp[i][2-count], count, MPI_DOUBLE, rowComm);
                }
                // Pack column and send left
                for(int i=0; i<leny; i++){
                    MPI_Pack(&data[i][2], count, MPI_DOUBLE, colSendBuf, colBufSz, &position, rowComm);
                }
                MPI_Send(colSendBuf, position, MPI_PACKED, rank-1, rank-1, rowComm);
            }
            if(col%2!=0 && col<Px-1){
                // Send/recv right neighbour from odd ranks
                // Pack column and send right
                position = 0;
                for(int i=0; i<leny; i++){
                    MPI_Pack(&data[i+2][lenx-count+2], count, MPI_DOUBLE, colSendBuf, colBufSz, &position, rowComm);
                }
                MPI_Send(colSendBuf, position, MPI_PACKED, rank+1, rank+1, rowComm);
                // Unpack received column
                MPI_Recv(colRecvBuf, colBufSz, MPI_PACKED, rank+1, rank, rowComm, &status);
                for(int i=0; i<leny; i++){
                    MPI_Unpack(colRecvBuf, colBufSz, &position, &temp[i+2][lenx+2], count, MPI_DOUBLE, rowComm);
                }
            }
            else if(col%2==0 && col>0){
                // Send/recv left neighbour from even ranks
                // Unpack received column
                position = 0;
                MPI_Recv(colRecvBuf, colBufSz, MPI_PACKED, rank-1, rank, rowComm, &status);
                for(int i=0; i<leny; i++){
                    MPI_Unpack(colRecvBuf, colBufSz, &position, &temp[i][2-count], count, MPI_DOUBLE, rowComm);
                }
                // Pack column and send left
                for(int i=0; i<leny; i++){
                    MPI_Pack(&data[i][2], count, MPI_DOUBLE, colSendBuf, colBufSz, &position, rowComm);
                }
                MPI_Send(colSendBuf, position, MPI_PACKED, rank-1, rank-1, rowComm);
            }
            if(leader==0){
                if(row%2==0 && row<Py-1){
                    // Send/recv bottom neighbour from even ranks
                    // Pack row and send bottom
                    position = 0;
                    for(int it=count; it>0; it--){
                        for(int i=0; i<lenx; i++){
                            MPI_Pack(&data[leny-it+2][i], 1, MPI_DOUBLE, rowSendBuf, rowBufSz, &position, MPI_COMM_WORLD);
                        }
                    }
                    MPI_Send(rowSendBuf, position, MPI_PACKED, rank+Px, rank+Px, MPI_COMM_WORLD);
                    // Unpack received row
                    MPI_Recv(rowRecvBuf, rowBufSz, MPI_PACKED, rank+Px, rank, MPI_COMM_WORLD, &status);
                    for(int it=0; it<count; it++){
                        for(int i=0; i<lenx; i++){
                            MPI_Unpack(rowRecvBuf, rowBufSz, &position, &temp[leny+it+2][i], 1, MPI_DOUBLE, MPI_COMM_WORLD);
                        }
                    }
                }
                else if(row%2!=0 && row>0){
                    // Send/recv top neighbour from odd ranks
                    // Unpack received row
                    position = 0;
                    MPI_Recv(rowRecvBuf, rowBufSz, MPI_PACKED, rank-Px, rank, MPI_COMM_WORLD, &status);
                    for(int it=count; it>0; it--){
                        for(int i=0; i<lenx; i++){
                            MPI_Unpack(rowRecvBuf, rowBufSz, &position, &temp[2-it][i], 1, MPI_DOUBLE, MPI_COMM_WORLD);
                        }
                    }
                    // Pack row and send top
                    for(int it=0; it<count; it++){
                        for(int i=0; i<lenx; i++){
                            MPI_Pack(&data[it+2][i], 1, MPI_DOUBLE, rowSendBuf, rowBufSz, &position, MPI_COMM_WORLD);
                        }
                    }
                    MPI_Send(rowSendBuf, position, MPI_PACKED, rank-Px, rank-Px, MPI_COMM_WORLD);
                }
                if(row%2!=0 && row<Py-1){
                    // Send/recv bottom neighbour from odd ranks
                    // Pack row and send bottom
                    position = 0;
                    for(int it=count; it>0; it--){
                        for(int i=0; i<lenx; i++){
                            MPI_Pack(&data[leny-it+2][i], 1, MPI_DOUBLE, rowSendBuf, rowBufSz, &position, MPI_COMM_WORLD);
                        }
                    }
                    MPI_Send(rowSendBuf, position, MPI_PACKED, rank+Px, rank+Px, MPI_COMM_WORLD);
                    // Unpack received row
                    MPI_Recv(rowRecvBuf, rowBufSz, MPI_PACKED, rank+Px, rank, MPI_COMM_WORLD, &status);
                    for(int it=0; it<count; it++){
                        for(int i=0; i<lenx; i++){
                            MPI_Unpack(rowRecvBuf, rowBufSz, &position, &temp[leny+it+2][i], 1, MPI_DOUBLE, MPI_COMM_WORLD);
                        }
                    }
                }
                else if(row%2==0 && row>0){
                    // Send/recv top neighbour from odd ranks
                    // Unpack received row
                    position = 0;
                    MPI_Recv(rowRecvBuf, rowBufSz, MPI_PACKED, rank-Px, rank, MPI_COMM_WORLD, &status);
                    for(int it=count; it>0; it--){
                        for(int i=0; i<lenx; i++){
                            MPI_Unpack(rowRecvBuf, rowBufSz, &position, &temp[2-it][i], 1, MPI_DOUBLE, MPI_COMM_WORLD);
                        }
                    }
                    // Pack row and send top
                    for(int it=0; it<count; it++){
                        for(int i=0; i<lenx; i++){
                            MPI_Pack(&data[it+2][i], 1, MPI_DOUBLE, rowSendBuf, rowBufSz, &position, MPI_COMM_WORLD);
                        }
                    }
                    MPI_Send(rowSendBuf, position, MPI_PACKED, rank-Px, rank-Px, MPI_COMM_WORLD);
                }
            }
            else{
                // Intra-node Gather call
                position = 0;
                // Pack Top Row
                for(int it=0; it<count; it++){
                    for(int i=0; i<lenx; i++){
                        MPI_Pack(&data[it+2][i], 1, MPI_DOUBLE, rowSendBuf, rowBufSz, &position, rowComm);
                    }
                }
                // Pack Bottom Row
                for(int it=count; it>0; it--){
                    for(int i=0; i<lenx; i++){
                        MPI_Pack(&data[leny-it+2][i], 1, MPI_DOUBLE, rowSendBuf, rowBufSz, &position, rowComm);
                    }
                }

                MPI_Gather(&intraNodeSendBuf, 2*count*lenx, MPI_DOUBLE, &intraNodeRecvBuf, 2*count*lenx, MPI_DOUBLE, 0, intraNodeComm);

                // Inter-node Send-Receive call
                if(col==0){
                    int interNodeRank, interNodeCommSz;
                    MPI_Comm_rank(interNodeComm, &interNodeRank);
                    MPI_Comm_size(interNodeComm, &interNodeCommSz);
                    char message[20]; message[0] = '\0'; 
                    char recvmessage[20]; recvmessage[0] = '\0';
                    strcpy(message,"Welcome");

                    if(interNodeRank%2==0 && interNodeRank<interNodeCommSz-1){
                        // Send/recv bottom neighbour from even ranks
                        // Pack row and send bottom
                        position = 0;
                        for(int it=0; it<Px; it++){
                            for(int i=0; i<count*lenx; i++){
                                MPI_Pack(&intraNodeRecvBuf[count*(2*it+1)*lenx+i], 1, MPI_DOUBLE, interNodeSendBuf, interNodeBufSz, &position, interNodeComm);
                            }
                        }
                        MPI_Send(interNodeSendBuf, position, MPI_PACKED, interNodeRank+1, interNodeRank+1, interNodeComm);
                        // Unpack received row
                        MPI_Recv(&interNodeRecvBuf[count*lenx*Px], interNodeBufSz, MPI_PACKED, interNodeRank+1, interNodeRank, interNodeComm, &status);
                    }
                    else if(interNodeRank%2!=0 && interNodeRank>0){
                        // Send/recv top neighbour from odd ranks
                        // Unpack received row
                        position = 0;
                        MPI_Recv(&interNodeRecvBuf, interNodeBufSz, MPI_PACKED, interNodeRank-1, interNodeRank, interNodeComm, &status);
                        // Pack row and send top
                        for(int it=0; it<Px; it++){
                            for(int i=0; i<count*lenx; i++){
                                MPI_Pack(&intraNodeRecvBuf[count*(2*it)*lenx+i], 1, MPI_DOUBLE, interNodeSendBuf, interNodeBufSz, &position, interNodeComm);
                            }
                        }
                        MPI_Send(interNodeSendBuf, position, MPI_PACKED, interNodeRank-1, interNodeRank-1, interNodeComm);
                    }
                    if(interNodeRank%2!=0 && interNodeRank<interNodeCommSz-1){
                        // Send/recv bottom neighbour from odd ranks
                        // Pack row and send bottom
                        position = 0;
                        for(int it=0; it<Px; it++){
                            for(int i=0; i<count*lenx; i++){
                                MPI_Pack(&intraNodeRecvBuf[count*(2*it+1)*lenx+i], 1, MPI_DOUBLE, interNodeSendBuf, interNodeBufSz, &position, interNodeComm);
                            }
                        }
                        MPI_Send(interNodeSendBuf, position, MPI_PACKED, interNodeRank+1, interNodeRank+1, interNodeComm);
                        // Unpack received row
                        MPI_Recv(&interNodeRecvBuf[count*lenx*Px], interNodeBufSz, MPI_PACKED, interNodeRank+1, interNodeRank, interNodeComm, &status);
                    }
                    else if(interNodeRank%2==0 && interNodeRank>0){
                        // Send/recv top neighbour from odd ranks
                        // Unpack received row
                        position = 0;
                        MPI_Recv(&interNodeRecvBuf, interNodeBufSz, MPI_PACKED, interNodeRank-1, interNodeRank, interNodeComm, &status);
                        // Pack row and send top
                        for(int it=0; it<Px; it++){
                            for(int i=0; i<count*lenx; i++){
                                MPI_Pack(&intraNodeRecvBuf[count*(2*it)*lenx+i], 1, MPI_DOUBLE, interNodeSendBuf, interNodeBufSz, &position, interNodeComm);
                            }
                        }
                        MPI_Send(interNodeSendBuf, position, MPI_PACKED, interNodeRank-1, interNodeRank-1, interNodeComm);
                    }
                }
                
                // Fix the received values ordering for scattering
                double tempScatterBuf[2*count*lenx*Px];
                position = 0;
                for(int i=0; i<count*lenx*Px; i+=count*lenx){
                    MPI_Unpack(interNodeSendBuf, interNodeBufSz, &position, &tempScatterBuf[2*i], count*lenx, MPI_DOUBLE, MPI_COMM_WORLD);
                }
                for(int i=count*lenx*Px; i<2*count*lenx*Px; i+=count*lenx){
                    MPI_Unpack(interNodeSendBuf, interNodeBufSz, &position, &tempScatterBuf[i-count*lenx*(Px-1)], count*lenx, MPI_DOUBLE, MPI_COMM_WORLD);
                }

                // Intra-node Scatter call
                MPI_Scatter(&tempScatterBuf, 2*count*lenx, MPI_DOUBLE, &intraNodeRecvSmallBuf, 2*count*lenx, MPI_DOUBLE, 0, intraNodeComm);

                // Unpack the received values
                position=0;
                for(int it=count; it>0; it--){
                    for(int i=0; i<lenx; i++){
                        MPI_Unpack(tempScatterBuf, rowBufSz, &position, &temp[2-it][i], 1, MPI_DOUBLE, intraNodeComm);
                    }
                }
                position = 0;
                for(int it=0; it<count; it++){
                    for(int i=0; i<lenx; i++){
                        MPI_Unpack(tempScatterBuf, rowBufSz, &position, &temp[leny+it+2][i], 1, MPI_DOUBLE, intraNodeComm);
                    }
                }
            }

            // Update values
            for(int i = 0; i < leny; i++){
                for(int j = 0; j < lenx; j++){
                    if(stencil == 5){
                        int num = temp[i+2][j+2], den = 1;
                        if (temp[i+1][j+2]!=-1) {num += temp[i+1][j+2]; den++;}
                        if (temp[i+3][j+2]!=-1) {num += temp[i+3][j+2]; den++;}
                        if (temp[i+2][j+1]!=-1) {num += temp[i+2][j+1]; den++;}
                        if (temp[i+2][j+3]!=-1) {num += temp[i+2][j+3]; den++;}
                        data[i+2][j+2] = num/den;
                    }
                    else if(stencil == 9){
                        int num = temp[i+2][j+2], den = 1;
                        if (temp[i+1][j+2]!=-1) {num += temp[i+1][j+2]; den++;}
                        if (temp[i+3][j+2]!=-1) {num += temp[i+3][j+2]; den++;}
                        if (temp[i+2][j+1]!=-1) {num += temp[i+2][j+1]; den++;}
                        if (temp[i+2][j+3]!=-1) {num += temp[i+2][j+3]; den++;}
                        if (temp[i][j+2]!=-1) {num += temp[i][j+2]; den++;}
                        if (temp[i+4][j+2]!=-1) {num += temp[i+4][j+2]; den++;}
                        if (temp[i+2][j]!=-1) {num += temp[i+2][j]; den++;}
                        if (temp[i+2][j+4]!=-1) {num += temp[i+2][j+4]; den++;}
                        data[i+2][j+2] = num/den;
                    }
                }
            }
            for(int i = 0; i < leny; i++){
                for(int j = 0; j < lenx; j++){
                    temp[i][j] = data[i][j];
                }
            }
        }
        eTime = MPI_Wtime();
        time = eTime - sTime;
        double maxTime;
        // Calculate max time taken by any process
        MPI_Reduce(&time, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        if(rank==0){
            if(leader==0) printf("Time with leader = %lf\n", maxTime);
            else printf("Time without leader = %lf\n", maxTime);
        }
    }
    if(rank==0){
        printf("Data = %lf", data[count][count]);
    }

    MPI_Finalize();
    return 0;
}