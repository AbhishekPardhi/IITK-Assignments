class test_25
{  
    public static void main(String args[])
    {  
	int x = 20;
	int y = 18;
	if (x > y) 
  		System.out.println("x is greater than y");
    }  
}

