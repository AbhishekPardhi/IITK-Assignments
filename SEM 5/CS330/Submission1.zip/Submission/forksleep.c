// Demonstrating working of fork().

#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
    if(argc!=3)
    {
        fprintf(2,"Invalid input format.\n");
        exit(1);
    }
    for(int i = 0; argv[1][i] != '\0'; i++)
    {
        if (argv[1][i] < '0' || argv[1][i] > '9')
        {
            fprintf(2,"Invalid m input.\n");
            exit(1);
        }
    }
    if (strcmp(argv[2],"0") && strcmp(argv[2],"1"))
    {
        fprintf(2,"Invalid n input.\n");
        exit(1);
    }
    int m, n, f;
    m = atoi(argv[1]);
    n = atoi(argv[2]);
    if (m == 0)
    {
        fprintf(2,"Invalid m input.\n");
        exit(1);
    }
    f=fork();
    if(f<0)
    {
		fprintf(2,"Cannot fork.\n");
		exit(1);
    }
    else if(f==0)
    {
        if(n==0) sleep(m);
        fprintf(1,"%d: Child\n",getpid());
    }
    else 
    {
        if(n==1) sleep(m);
        fprintf(1,"%d: Parent\n",getpid());
        wait(0);
    }
    exit(0);
}