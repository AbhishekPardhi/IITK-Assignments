// Prints uptime.

#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "user.h"

int main(void)
{
    fprintf(1,"uptime is %d\n", uptime());
    exit(0);
}