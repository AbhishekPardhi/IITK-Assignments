// Demonstrating use of pipeline.

#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "user.h"

int main (int argc, char *argv[])
{
	if (argc != 3)
    {
		fprintf(2,"Invalid input format.\n");
		exit(1);
	}
    for(int i = 0; argv[1][i] != '\0'; i++)
    {
        if (argv[1][i] < '0' || argv[1][i] > '9')
        {
            fprintf(2,"Incorrect n input.\n");
            exit(1);
        }
    }
    int val=0, flag=0;
    for(int i = 0; argv[2][i] != '\0'; i++)
    {
        if (i == 0 && argv[2][0] == '-')
        {
            flag=1;
            continue;
        }
        if (argv[2][i] < '0' || argv[2][i] > '9')
        {
            fprintf(2,"Incorrect x input.\n");
            exit(1);
        }
        val=val*10+(argv[2][i]-'0');
    }
	int pipex[2];
	int n, x, f, w;
    n=atoi(argv[1]);
    if(n==0)
    {
        fprintf(2,"Invalid n input.\n");
        exit(1);
    }
    if(flag==1) x=-val;
    else x=val;
	if (pipe(pipex) < 0)
    {
		fprintf(2,"Cannot create pipe.\n");
		exit(1);
	}
    if(n==1)
    {
        fprintf(1,"%d: %d\n",getpid(),x+getpid());
        exit(0);
    }
    f = fork();
    for(int i=0;i<n-1;i++)
    {
        if (f < 0)
        {
            fprintf(2,"Cannot fork.\n");
            exit(1);
        }
        else if (f > 0)
        {
            if(i==0)
            {
                x += getpid();
                fprintf(1,"%d: %d\n",getpid(),x);
            }
            write(pipex[1], &x, sizeof(int));
            close(pipex[0]);
            close(pipex[1]);
            wait(0);
            break;
        }
        else
        {
            read(pipex[0], &w, sizeof(int));
            w += getpid();
            fprintf(1,"%d: %d\n",getpid(),w);
            f = fork();
            close(pipex[0]);
            close(pipex[1]);
        }
    }
    exit(0);
}