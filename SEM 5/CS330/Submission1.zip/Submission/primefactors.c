// Prints the prime factors of n with multiplicity

#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "user.h"

int primes[]={2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97};

int main (int argc, char *argv[])
{
	if (argc != 2)
    {
		fprintf(2,"Invalid input format.\n");
		exit(1);
	}
    for(int i = 0; argv[1][i] != '\0'; i++)
    {
        if (argv[1][i] < '0' || argv[1][i] > '9')
        {
            fprintf(2,"Incorrect n input.");
            exit(1);
        }
    }
	int pipex[2];
	int n, f, w, sz;
    sz=25;
    n=atoi(argv[1]);
    if(n<2 || n>100)
    {
        fprintf(2,"Incorrect n input.");
        exit(1);
    }
	if (pipe(pipex) < 0)
    {
		fprintf(2,"Cannot create pipe.\n");
		exit(0);
	}
    f = fork();
    for(int i=0;i<sz-1;i++)
    {
        if (f < 0)
        {
            fprintf(2,"Cannot fork.\n");
            exit(1);
        }
        else if (f > 0)
        {
            int flag=(n%primes[i]==0);
            while(n%primes[i]==0)
            {
                fprintf(1,"%d, ",primes[i]);
                n/=primes[i];
            }
            if(flag) fprintf(1,"[%d]\n",getpid());
            write(pipex[1], &n, sizeof(int));
            close(pipex[0]);
            close(pipex[1]);
            wait(0);
            break;
        }
        else
        {
            sleep(1);
            read(pipex[0], &w, sizeof(int));
            n=w;
            if(n==1) break;
            close(pipex[0]);
            close(pipex[1]);
            f = fork();
        }
    }
    exit(0);
}